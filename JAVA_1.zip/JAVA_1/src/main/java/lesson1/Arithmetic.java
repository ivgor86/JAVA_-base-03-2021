package lesson1;

public class Arithmetic {
    public static void main(String[] args) {
        // + - * %
        int a = 5, b = 3, c= 7, d = 8;
        System.out.println((float) a * (b + (c / d) ) );
    }
}
