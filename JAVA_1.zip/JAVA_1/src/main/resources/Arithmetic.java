package lesson1;

public class Arithmetic {

}
